# Keep It Down

Simple volume tuning mod for Lethal Company. The settings can be edited either through the ingame UI, or through BepInEx config.

![Mod Settings Window](https://github.com/Kesomannen/KeepItDown/assets/113015915/39229796-b2e2-4712-9d42-fd6c2d51f2dd)

## Installation

Go to [the thunderstore page](https://thunderstore.io/package/Kesomannen/KeepItDown/) to get the latest version. If you choose to do download manually, simply add `KeepItDown.dll` to your `/BepInEx/plugins` folder under the game directory. Note that `LethalSettings` is required as a dependency.
